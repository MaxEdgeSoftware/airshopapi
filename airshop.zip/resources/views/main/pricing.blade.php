@extends('layouts.app')


@section('title')
<meta name="description" content="#1 Ecommerce Solution for all types of business.. Airshop247, your digital space">
<title>PRICING  - AIRSHOP</title>
@endsection

@section('styles')
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  <link rel="stylesheet" href="{{ asset('css/pricing.css') }}">
@endsection

@section('content')

  <example-component></example-component>

@endsection