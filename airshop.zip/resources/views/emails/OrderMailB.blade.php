@component('mail::message')
# Dear Buyer,

Your order has been received, the Vendor will contact you within the next 15mins.


Thanks,<br>
{{ config('app.name') }}
@endcomponent
